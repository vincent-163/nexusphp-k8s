<?php
# IMPORTANT: Do not edit below unless you know what you are doing!
define('IN_TRACKER', true);
$rootpath=realpath(dirname(__FILE__) . '/..')."/";
include($rootpath . 'include/core.php');
include_once($rootpath . 'include/functions_announce.php');
?>
