<?php

$lang_attachment = array
(
	'text_nothing_received' => "失敗！沒有收到檔案！",
	'text_file_number_limit_reached' => "失敗！你暫時無法上傳更多屬裝置！請等待些時間。",
	'text_file_size_too_big' => "失敗！檔案過大。",
	'text_file_extension_not_allowed' => "失敗！不允許該檔案副檔名。",
	'text_invalid_image_file' => "失敗！圖片檔案無效。",
	'text_cannot_move_file' => "失敗！無法移動上傳的檔案。",
	'submit_upload' => "上傳",
	'text_left' => "今日剩餘：",
	'text_of' => "/",
	'text_size_limit' => "大小限制：",
	'text_file_extensions' => "允許副檔名：",
	'text_mouse_over_here' => "滑鼠移至此",
	'text_small_thumbnail' => "小縮略圖",
);

?>
