<?php

$lang_ipsearch = array
(
	'std_error' => "錯誤",
	'std_invalid_ip' => "無效的IP位址。",
	'std_invalid_subnet_mask' => "無效的網路遮罩。",
	'head_search_ip_history' => "搜索IP曆史",
	'text_search_ip_history' => "搜索IP曆史",
	'row_ip' => "IP",
	'row_subnet_mask' => "網路遮罩",
	'submit_search' => "給我搜",
	'text_no_users_found' => "沒有找到用戶",
	'text_users_used_the_ip' => "個用戶使用過此IP：",
	'col_username' => "用戶名",
	'col_last_ip' => "最近IP",
	'col_last_access' => "最近存取",
	'col_ip_num' => "IP數",
	'col_last_access_on' => "此IP最近存取",
	'col_added' => "加入時間",
	'col_invited_by' => "邀請者",
	'text_not_available' => "無",
);
?>
