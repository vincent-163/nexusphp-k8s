<?php

$lang_moresmilies = array
(
	'head_more_smilies' => "更多可點表情",
	'text_close' => "關閉",
);

?>
