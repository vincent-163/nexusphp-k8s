<?php

$lang_takelogin = array
(
	'std_login_fail_note' => "<b>錯誤</b>: 用戶名或密碼不正確！<br /><br />忘記密碼了？<b><a href=recover.php>找回</a></b>你的密碼！",
	'std_login_fail' => "登錄失敗！",
	'std_account_disabled' => "該帳號已被禁用。",
	'std_user_account_unconfirmed' => "該賬戶還未通過驗證。如果你沒有收到驗證郵件，試試<a href='confirm_resend.php'><b>重新發送驗證郵件</b></a>。",
);

?>
