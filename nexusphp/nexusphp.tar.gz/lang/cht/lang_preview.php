<?php

$lang_preview = array
(
	'text_preview' => "預覽"
);

?>