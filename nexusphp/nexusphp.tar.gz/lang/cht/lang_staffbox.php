<?php

$lang_staffbox = array
(
	'head_staff_pm' => "管理組信箱",
	'text_staff_pm' => "管理組信箱",
	'std_sorry' => "對不起",
	'std_no_messages_yet' => "暫時沒有短訊！",
	'col_subject' => "主題",
	'col_sender' => "發訊者",
	'col_added' => "時間",
	'col_answered' => "回復",
	'col_action' => "行為",
	'text_yes' => "是",
	'text_no' => "否",
	'submit_set_answered' => "設為已回復",
	'submit_delete' => "刪除",
	'text_system' => "系統",
	'head_view_staff_pm' => "查看管理組信箱",
	'col_from' => "自",
	'col_date' => "日期",
	'col_answered_by' => "回復者",
	'text_reply' => "回復",
	'text_mark_answered' => "設為已回復",
	'text_delete' => "刪除",
	'std_error' => "錯誤",
	'std_no_user_id' => "沒有此ID的用戶。",
	'head_answer_to_staff_pm' => "回復管理組信息",
	'text_answering_to' => "回復",
	'text_sent_by' => " - 來自",
	'std_body_is_empty' => "回復不能為空白！",
);

?>
