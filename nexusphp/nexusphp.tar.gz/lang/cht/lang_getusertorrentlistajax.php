<?php

$lang_getusertorrentlistajax = array
(
	'col_type' => "類別",
	'col_name' => "標題",
	'title_size' => "大小",
	'title_seeders' => "種子數",
	'title_leechers' => "下載數",
	'col_uploaded' => "上傳",
	'col_downloaded' => "下載",
	'col_ratio' => "分享率",
	'col_anonymous' => "匿名",
	'col_time_completed' => "完成時間",
	'col_se_time' => "做種時間",
	'col_le_time' => "下載時間",
	'text_record' => "條記錄",
	'text_no_record' => "沒有記錄",
);
?>
