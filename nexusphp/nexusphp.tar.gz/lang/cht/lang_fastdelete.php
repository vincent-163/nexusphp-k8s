<?php

$lang_fastdelete = array
(
	'std_delete_failed' => "刪除失敗！",
	'std_missing_form_data' => "有項目沒填",
	'text_no_permission' => "你沒有許可權刪除該種子，只有版主及以上用戶才可以。如果你想刪除自己發佈的種子，請聯繫他們。\n",
	'std_delete_torrent' => "刪除種子",
	'std_delete_torrent_note' => "確認：你即將刪除種子，點擊",
	'std_here_if_sure' => "這裏</a>來確認。"
);

?>
