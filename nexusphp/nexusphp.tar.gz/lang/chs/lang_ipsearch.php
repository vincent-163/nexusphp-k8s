<?php

$lang_ipsearch = array
(
	'std_error' => "错误",
	'std_invalid_ip' => "无效的IP地址。",
	'std_invalid_subnet_mask' => "无效的子网掩码。",
	'head_search_ip_history' => "搜索IP历史",
	'text_search_ip_history' => "搜索IP历史",
	'row_ip' => "IP",
	'row_subnet_mask' => "子网掩码",
	'submit_search' => "给我搜",
	'text_no_users_found' => "没有找到用户",
	'text_users_used_the_ip' => "个用户使用过此IP：",
	'col_username' => "用户名",
	'col_last_ip' => "最近IP",
	'col_last_access' => "最近访问",
	'col_ip_num' => "IP数",
	'col_last_access_on' => "此IP最近访问",
	'col_added' => "加入时间",
	'col_invited_by' => "邀请者",
	'text_not_available' => "无",
);
?>
