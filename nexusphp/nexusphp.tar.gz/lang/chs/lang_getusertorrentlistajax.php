<?php

$lang_getusertorrentlistajax = array
(
	'col_type' => "类型",
	'col_name' => "标题",
	'title_size' => "大小",
	'title_seeders' => "种子数",
	'title_leechers' => "下载数",
	'col_uploaded' => "上传",
	'col_downloaded' => "下载",
	'col_ratio' => "分享率",
	'col_anonymous' => "匿名",
	'col_time_completed' => "完成时间",
	'col_se_time' => "做种时间",
	'col_le_time' => "下载时间",
	'text_record' => "条记录",
	'text_no_record' => "没有记录",
);
?>
