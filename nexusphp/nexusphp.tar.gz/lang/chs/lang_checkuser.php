<?php

$lang_checkuser = array
(
	'std_error' => "错误",
	'std_no_user_id' => "没有该ID的用户！",
	'std_no_permission' => "你没有该权限",
	'head_detail_for' => "用户详情 - ",
	'text_account_disabled' => "<p><b>该账号被禁用！</b></p>\n",
	'row_join_date' => "加入日期",
	'row_gender' => "性别",
	'row_email' => "邮箱",
	'row_ip' => "IP",
	'submit_confirm_this_user' => "确认该用户",
);

?>
