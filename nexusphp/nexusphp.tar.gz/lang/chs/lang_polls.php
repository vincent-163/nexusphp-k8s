<?php

$lang_polls = array
(
	'std_error' => "错误",
	'std_permission_denied' => "你没有该权限",
	'std_delete_poll' => "删除投票",
	'std_delete_poll_confirmation' => "你确定要删除该投票吗？点击\n",
	'std_here_if_sure' => "<b>这里</b></a>来确认。",
	'std_sorry' => "对不起...",
	'std_no_polls' => "暂时没有投票！",
	'head_previous_polls' => "以前的投票",
	'text_previous_polls' => "以前的投票",
	'text_ago' => "以前",
	'text_edit' => "编辑",
	'text_delete' => "删除",
	'text_votes' => "投票数："
);

?>