<?php

$lang_viewnfo = array
(
	'std_puke' => "奧哦",
	'head_view_nfo' => "查看NFO文件",
	'text_nfo_for' => "NFO文件：",
	'title_dos_vy' => "查看DOS样式",
	'text_dos_vy' => "DOS样式",
	'title_windows_vy' => "查看Windows样式",
	'text_windows_vy' => "Windows样式"
);

?>