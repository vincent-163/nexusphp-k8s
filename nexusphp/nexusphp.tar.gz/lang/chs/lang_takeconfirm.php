<?php

$lang_takeconfirm = array
(
	'std_sorry' => "对不起...",
	'std_no_buddy_to_confirm' => "没有需要验证的用户。:( <br /><br />请点击",
	'std_here_to_go_back' => "这里</a>返回。",
	'mail_title' => "网站账户验证",
	'mail_here' => "这里",
	'mail_content_1' => "你好,<br /><br />你的账号成功通过验证。你可以进入登录页面: ",
	'mail_content_2' => "<br /><br />使用你的账户登录。登录后请先阅读站点规则，提问前请自行参考常见问题。<br /><br />祝你好运！ ".$SITENAME."!<br /><br />如果你不认识邀请你的人，请将本邮件转发至".$REPORTMAIL."<br />------<br />".$SITENAME." 网站"
);

?>
