<?php

$lang_forummanage = array
(
	'head_forum_management' => "论坛管理",
	'text_forum_management' => "论坛管理",
	'text_edit_forum' => "编辑论坛版块",
	'row_forum_name' => "版块名字",
	'row_forum_description' => "版块描述",
	'row_overforum' => "论坛分区",
	'row_moderator' => "版主",
	'text_moderator_note' => "最多3个版主。用','分割用户名",
	'row_minimum_read_permission' => "最低允许阅读等级",
	'row_minimum_write_permission' => "最低允许回复等级",
	'row_minimum_create_topic_permission' => "最低允许发布主题等级",
	'row_forum_order' => "论坛版块排序",
	'text_forum_order_note' => "按数字升序排列，即0显示在最顶端。",
	'submit_edit_forum' => "编辑论坛版块",
	'text_no_records_found' => "对不起，没有记录！",
	'text_add_forum' => "添加论坛版块",
	'text_make_new_forum' => "添加新的版块",
	'submit_overforum_management' => "论坛分区管理",
	'submit_add_forum' => "添加版块",
	'col_name' => "名字",
	'col_overforum' => "论坛分区",
	'col_read' => "读",
	'col_write' => "回复",
	'col_create_topic' => "创建主题",
	'col_moderator' => "版主",
	'col_modify' => "修改",
	'text_not_available' => "暂无",
	'text_edit' => "编辑",
	'text_delete' => "删除",
	'js_sure_to_delete_forum' => "你确定要删除此论坛版块吗？",
	'submit_make_forum' => "创建论坛版块"
);

?>
