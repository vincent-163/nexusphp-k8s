<?php

$lang_delete = array
(
	'std_delete_failed' => "删除失败！",
	'std_missing_form_date' => "有项目未填",
	'std_not_owner' => "你不是发种者！你怎么会来这？\n",
	'std_invalid_reason' => "无效的理由",
	'std_describe_violated_rule' => "请填写具体违反的规则。",
	'std_enter_reason' => "请填写删除该种子的原因。",
	'head_torrent_deleted' => "成功删除种子！",
	'text_go_back' => "回到刚才的地方",
	'text_back_to_index' => "返回首页",
	'text_torrent_deleted' => "成功删除种子！",
);

?>