<?php

$lang_takeflush = array
(
	'std_failed' => "失败",
	'std_success' => "成功",
	'std_ghost_torrents_cleaned' => "个冗余种子被成功清除。",
	'std_cannot_flush_others' => "你只能清除自己的冗余种子"
);

?>