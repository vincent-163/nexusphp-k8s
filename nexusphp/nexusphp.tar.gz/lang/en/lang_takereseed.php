<?php

$lang_takereseed = array
(
	'head_reseed_request' => "Reseed Request!",
	'std_it_worked' => "It worked! A message is sent to users who have snatched this torrent.",
	'std_error' => "Error",
	'std_torrent_not_dead' => "The torrent is not dead.",
	'std_reseed_sent_recently' => "Someone already asked for reseed of this torrent in last 15 minutes. Please wait patiently for users to reseed.",
);

?>
