<?php

$lang_shoutbox = array
(
	'text_del' => "del",
	'std_access_denied' => "Access Denied.",
	'std_access_denied_note' => "Guests are not allowed to see this page.",
	'text_to_guest' => " to <b>Guest</b>",
	'text_guest' => "<b>Guest</b>",
	'text_ago' => " ago",
	'text_helpbox_disabled' => "Helpbox is currently disabled. How the hell do you get here?",
	'text_no_permission_to_shoutbox' => "You have no permission to send messages to shoutbox. How the hell do you get here?",
);

?>
