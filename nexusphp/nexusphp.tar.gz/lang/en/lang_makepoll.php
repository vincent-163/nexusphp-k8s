<?php

$lang_makepoll = array
(
	'std_error' => "Error",
	'std_no_poll_id' => "No poll found with this ID",
	'std_missing_form_data' => "Missing form data!",
	'head_edit_poll' => "Edit Poll",
	'text_edit_poll' => "Edit Poll",
	'head_new_poll' => "New Poll",
	'text_day' => " day",
	'text_hour' => " hour",
	'text_current_poll' => "Note: The current poll ",
	'text_is_only' => " is only ",
	'text_old' => " old.",
	'text_make_poll' => "Make poll",
	'text_question' => "Question",
	'text_option' => "Option ",
	'submit_edit_poll' => "Edit Poll",
	'submit_create_poll' => "Create Poll",
	'text_required' => " required"
);

?>
