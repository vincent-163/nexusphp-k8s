<?php

$lang_rules = array
(
	'head_rules' => "Rules"
);

?>