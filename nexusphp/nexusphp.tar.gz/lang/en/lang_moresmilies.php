<?php

$lang_moresmilies = array
(
	'head_more_smilies' => "More Clickable Smilies",
	'text_close' => "Close",
);

?>
