<?php

$lang_deletemessage = array
(
	'std_bad_message_id' => "Bad message ID",
	'std_not_suggested' => "I wouldn't do that if i were you...",
	'std_not_in_inbox' => "The message is not in your Inbox.",
	'std_not_in_sentbox' => "The message is not in your Sentbox.",
	'std_unknown_pm_type' => "Unknown PM type."
);

?>