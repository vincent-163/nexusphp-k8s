<?php

$lang_moforums = array
(
	'head_overforum_management' => "Overforum Management",
	'text_forum_management' => "Forum Management",
	'text_overforum_management' => "Overforum Management",
	'col_name' => "Name",
	'col_viewed_by' => "Viewed By",
	'col_modify' => "Modify",
	'text_edit' => "Edit",
	'text_delete' => "Delete",
	'js_sure_to_delete_overforum' => "Are you sure you want to delete this overforum?",
	'text_no_records_found' => "Sorry, no records were found!",
	'text_new_overforum' => "New Overforum",
	'text_overforum_name' => "Overforum name",
	'text_overforum_description' => "Overforum description",
	'text_minimum_view_permission' => "Minimum view permission",
	'text_overforum_order' => "Overforum order",
	'text_overforum_order_note' => "Order by number ascendantly. That is, 0 shows on the topmost",
	'submit_make_overforum' => "Make Overforum",
	'text_edit_overforum' => "Edit Overforum",
	'submit_edit_overforum' => "Edit Overforum"
);

?>
