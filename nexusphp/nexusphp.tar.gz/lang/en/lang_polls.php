<?php

$lang_polls = array
(
	'std_error' => "Error",
	'std_permission_denied' => "Permission denied.",
	'std_delete_poll' => "Delete poll",
	'std_delete_poll_confirmation' => "Do you really want to delete a poll? Click\n",
	'std_here_if_sure' => "<b>here</b></a> if you are sure.",
	'std_sorry' => "Sorry...",
	'std_no_polls' => "There are no polls!",
	'head_previous_polls' => "Previous polls",
	'text_previous_polls' => "Previous polls",
	'text_ago' => " ago",
	'text_edit' => "Edit",
	'text_delete' => "Delete",
	'text_votes' => "Votes: "
);

?>