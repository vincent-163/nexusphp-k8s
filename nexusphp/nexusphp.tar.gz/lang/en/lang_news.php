<?php

$lang_news = array
(
	'std_delete_news_item' => "Delete news item",
	'std_are_you_sure' => "Do you really want to delete a news item? Click ",
	'std_here' => "here",
	'std_if_sure' => " if you are sure.",
	'std_error' => "Error",
	'std_news_body_empty' => "The news body cannot be empty!",
	'std_news_title_empty' => "The news title cannot be empty!",
	'std_something_weird_happened' => "Something weird just happened.",
	'std_invalid_news_id' => "No news item with ID ",
	'head_edit_site_news' => "Edit Site News",
	'text_edit_site_news' => "Edit Site News",
	'text_notify_users_of_this' => "Notify users of this.",
	'head_site_news' => "Site News",
	'text_submit_news_item' => "Submit news item"
);

?>
