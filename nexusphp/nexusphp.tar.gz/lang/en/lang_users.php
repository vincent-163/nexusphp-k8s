<?php

$lang_users = array
(
	'head_users' => "Users",
	'text_users' => "<h1>Users</h1>",
	'text_search' => "Search:",
	'select_any_class' => "(any class)",
	'submit_okay' => "Okay",
	'text_prev' => "Prev",
	'text_next' => "Next",
	'col_user_name' => "User name",
	'col_registered' => "Registered",
	'col_last_access' => "Last access",
	'col_class' => "Class",
	'col_country' => "Country",
	'select_any_country'=> "(any country)",
);

?>
