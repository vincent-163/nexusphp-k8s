<?php

$lang_takereseed_target = array
(
	'en' => array
	(
	'msg_reseed_request' => "Reseed Request",
	'msg_reseed_user' => "User ",
	'msg_ask_reseed' => " asked for a reseed on torrent ",
	'msg_thank_you' => " !\nThank You!",
	),
	'chs' => array
	(
	'msg_reseed_request' => "续种请求",
	'msg_reseed_user' => "用户",
	'msg_ask_reseed' => "请求你续种该种子 - ",
	'msg_thank_you' => " ！谢谢你！",
	),
	'cht' => array
	(
	'msg_reseed_request' => "續種請求",
	'msg_reseed_user' => "用戶",
	'msg_ask_reseed' => "請求你續種該種子 - ",
	'msg_thank_you' => " ！謝謝你！",
	),
	'ko' => array
	(
	'msg_reseed_request' => "재시딩 요청",
	'msg_reseed_user' => "사용자 ",
	'msg_ask_reseed' => " 재시딩 요청이 있습니다. ",
	'msg_thank_you' => " !\n감사합니다!",
	),
	'ja' => array
	(
	'msg_reseed_request' => "Reseed Request",
	'msg_reseed_user' => "User ",
	'msg_ask_reseed' => " asked for a reseed on torrent ",
	'msg_thank_you' => " !\nThank You!",
	),
);

?>
